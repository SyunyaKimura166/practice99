import anyio
from claude_agent_sdk import query
from claude_agent_sdk.types import ClaudeAgentOptions
from claude_agent_sdk._internal.transport.subprocess_cli import SubprocessCLITransport
from pathlib import Path
from pprint import pprint

async def main():
    try:
        # Use the local Claude CLI installation that supports --setting-sources
        local_claude_path = Path("./node_modules/.bin/claude")

        # GitHub MCP server configuration (correct format for ClaudeAgentOptions)
        github_mcp_config = {
            "github": {
                "type": "stdio",
                "command": "docker",
                "args": [
                    "run",
                    "-i",
                    "--rm",
                    "-e",
                    "GITHUB_PERSONAL_ACCESS_TOKEN",
                    "ghcr.io/github/github-mcp-server"
                ],
                "env": {
                    "GITHUB_PERSONAL_ACCESS_TOKEN": "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"
                }
            }
        }

        options = ClaudeAgentOptions(
            permission_mode='bypassPermissions',
            mcp_servers=github_mcp_config,
            allowed_tools=[]
        )

        # Create transport with explicit CLI path
        transport = SubprocessCLITransport(
            prompt="IoVPF-AgenticSoftwareEngineeringオーナーのリポジトリ一覧を表示してください。",
            options=options,
            cli_path=local_claude_path
        )

        print("🔌 Claude Agent SDKを開始しています...")
        print("🐳 GitHub MCP サーバー（Docker）への接続を試行中...")

        # Get repository data using GitHub MCP
        async for message in query(
            prompt="IoVPF-AgenticSoftwareEngineeringオーナーのリポジトリ名のみを簡潔にリスト表示してください",
            options=options,
            transport=transport
        ):
            # Log MCP server connection status
            if hasattr(message, 'data') and isinstance(message.data, dict):
                if message.data.get('type') == 'system' and message.data.get('subtype') == 'init':
                    mcp_servers = message.data.get('mcp_servers', [])
                    if mcp_servers:
                        for server in mcp_servers:
                            status = server.get('status', 'unknown')
                            name = server.get('name', 'unknown')
                            if status == 'connected':
                                print(f"✅ MCP サーバー '{name}' に正常に接続しました")
                            else:
                                print(f"❌ MCP サーバー '{name}' の接続に失敗: {status}")

                    tools = message.data.get('tools', [])
                    github_tools = [tool for tool in tools if tool.startswith('mcp__github__')]
                    if github_tools:
                        print(f"🔧 GitHub MCP ツールが利用可能です（{len(github_tools)}個のツール）")

            # Log GitHub tool usage
            if hasattr(message, 'content') and message.content:
                for content in message.content:
                    if hasattr(content, 'name') and content.name and content.name.startswith('mcp__github__'):
                        tool_name = content.name.replace('mcp__github__', '')
                        print(f"🛠️  GitHub MCP ツールを実行中: {tool_name}")
                        if hasattr(content, 'input') and content.input:
                            query_info = content.input.get('query', '')
                            if query_info:
                                print(f"   📋 検索クエリ: {query_info}")

            # Only print the final result (repository list)
            if hasattr(message, 'result') and message.result:
                print("📊 リポジトリ一覧を取得しました:")
                print("" + "="*50)

                # Extract repository names and print each on a new line
                result_text = message.result
                if 'リポジトリ' in result_text:
                    # Find lines with repository names (marked with ** or numbered)
                    lines = result_text.split('\n')
                    for line in lines:
                        if '**' in line and '**' in line:
                            # Extract repo name between ** markers
                            start = line.find('**') + 2
                            end = line.find('**', start)
                            if end > start:
                                repo_name = line[start:end]
                                print(f"📁 {repo_name}")
                        elif line.strip().startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.')):
                            # Extract from numbered list
                            if '**' in line:
                                start = line.find('**') + 2
                                end = line.find('**', start)
                                if end > start:
                                    repo_name = line[start:end]
                                    print(f"📁 {repo_name}")

                print("" + "="*50)
                print("✅ 処理が完了しました")

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

anyio.run(main)
 