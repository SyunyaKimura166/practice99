#!/usr/bin/env python3
"""
認証機能実装比較ツール

Claude Agent SDKを使用して2つのサブエージェントが並行して
認証機能の実装方法を検討します。

サブエージェント1: JWTベースの認証
サブエージェント2: セッションベースの認証
"""

import asyncio

try:
    from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, TextBlock
except ImportError:
    print("❌ claude-agent-sdk がインストールされていません。")
    print("インストール: pip install claude-agent-sdk")
    exit(1)


async def jwt_agent():
    """JWT認証を分析するサブエージェント"""
    print("🔐 サブエージェント1: JWT認証の分析を開始...")

    system_prompt = """
あなたはWebアプリケーション開発の専門家です。
JWT（JSON Web Token）を使った認証システムの実装について、
以下の観点から詳細に分析してください：

1. JWTの仕組みと特徴
2. 実装のメリット・デメリット
3. セキュリティ上の考慮事項
4. 具体的な実装例（Python/Node.js/Go等）
5. 使用すべきケース

技術的に正確で実装可能なコード例を含めて回答してください。
"""

    prompt = """
認証機能の実装方法について、JWTを使ったアプローチで詳細に検討してください。

具体的には：
- JWTの基本概念と動作原理
- メリット・デメリットの詳細な分析
- セキュリティベストプラクティス
- 実装例（バックエンドAPI、フロントエンド連携）
- 実際の導入時の注意点

開発チームが実装判断できるレベルの詳細な情報を提供してください。
"""

    options = ClaudeAgentOptions(
        system_prompt=system_prompt,
        max_turns=1
    )

    response_text = ""
    async for message in query(prompt=prompt, options=options):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    response_text += block.text

    print("✅ JWT認証の分析完了")
    return response_text


async def session_agent():
    """セッション認証を分析するサブエージェント"""
    print("🍪 サブエージェント2: セッション認証の分析を開始...")

    system_prompt = """
あなたはWebアプリケーション開発の専門家です。
セッションベースの認証システムの実装について、
以下の観点から詳細に分析してください：

1. セッション認証の仕組みと特徴
2. 実装のメリット・デメリット
3. セキュリティ上の考慮事項
4. 具体的な実装例（Python/Node.js/Go等）
5. 使用すべきケース

技術的に正確で実装可能なコード例を含めて回答してください。
"""

    prompt = """
認証機能の実装方法について、セッションベースのアプローチで詳細に検討してください。

具体的には：
- セッション認証の基本概念と動作原理
- メリット・デメリットの詳細な分析
- セキュリティベストプラクティス
- 実装例（サーバーサイド、クッキー管理）
- 実際の導入時の注意点

開発チームが実装判断できるレベルの詳細な情報を提供してください。
"""

    options = ClaudeAgentOptions(
        system_prompt=system_prompt,
        max_turns=1
    )

    response_text = ""
    async for message in query(prompt=prompt, options=options):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    response_text += block.text

    print("✅ セッション認証の分析完了")
    return response_text


async def main():
    """メイン実行関数"""
    print("🔐 認証機能実装比較ツール")
    print("Claude Agent SDKを使用したサブエージェント並行実行")
    print("="*60)

    try:
        print("🚀 2つのサブエージェントを並行実行中...")

        # 2つのエージェントを並行実行
        jwt_result, session_result = await asyncio.gather(
            jwt_agent(),
            session_agent()
        )

        print("\n🎯 並行分析完了！")
        print("="*80)

        # JWT認証の結果
        print("\n🔐 【サブエージェント1】JWT認証の分析結果:")
        print("-" * 60)
        print(jwt_result)

        # セッション認証の結果
        print("\n\n🍪 【サブエージェント2】セッション認証の分析結果:")
        print("-" * 60)
        print(session_result)

        print("\n" + "="*80)
        print("🎉 認証方式の比較分析が完了しました！")

    except KeyboardInterrupt:
        print("\n🛑 実行が中断されました")
    except Exception as e:
        print(f"❌ 予期しないエラー: {e}")


if __name__ == "__main__":
    asyncio.run(main())