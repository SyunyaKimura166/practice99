"""
Sample Python code for testing Claude Code Sub-Agent review functionality.
This file intentionally contains various code quality issues to demonstrate
the sub-agent's review capabilities.
"""

import os
import json
import requests
from datetime import datetime


# Global variable (not recommended pattern)
USER_DATA = {}


def get_user_info(user_id):
    """Get user information from API - has security and error handling issues"""
    # Missing input validation (SECURITY ISSUE)
    url = f"https://api.example.com/users/{user_id}"
    
    # No error handling for HTTP requests (ERROR HANDLING ISSUE)
    response = requests.get(url)
    data = response.json()
    
    # Storing data in global variable (CODE QUALITY ISSUE)
    USER_DATA[user_id] = data
    
    # Logging sensitive information (SECURITY ISSUE)
    print(f"Retrieved user data: {data}")
    
    return data


def calculate_total(items):
    """Calculate total price - has performance and error handling issues"""
    total = 0
    
    # No input validation (ERROR HANDLING ISSUE)
    for item in items:
        # Potential KeyError if 'price' key doesn't exist (ERROR HANDLING ISSUE)
        total += item['price']
    
    # Division by zero risk (ERROR HANDLING ISSUE)
    average = total / len(items)
    
    return total, average


def save_to_file(data, filename):
    """Save data to file - has security issues"""
    # No path validation - potential directory traversal (SECURITY ISSUE)
    # No file existence check
    with open(filename, 'w') as f:
        json.dump(data, f)
    
    print(f"Data saved to {filename}")


class UserManager:
    def __init__(self):
        self.users = []
        
    def add_user(self, name, email, password):
        """Add user - has security and validation issues"""
        # No input validation (SECURITY ISSUE)
        # Password stored in plain text (SECURITY ISSUE)
        user = {
            'id': len(self.users) + 1,
            'name': name,
            'email': email,
            'password': password,  # Should be hashed!
            'created_at': datetime.now().isoformat()
        }
        
        self.users.append(user)
        return user
    
    def find_user(self, email):
        """Find user by email - has performance issues"""
        # Linear search - could be optimized (PERFORMANCE ISSUE)
        for user in self.users:
            if user['email'] == email:
                return user
        return None
    
    def delete_user(self, user_id):
        """Delete user - has validation and performance issues"""
        # No validation if user exists (ERROR HANDLING ISSUE)
        # Inefficient removal method (PERFORMANCE ISSUE)
        for i, user in enumerate(self.users):
            if user['id'] == user_id:
                del self.users[i]
                break


def process_payment(amount, card_number):
    """Process payment - critical security issues"""
    # Logging sensitive card information (CRITICAL SECURITY ISSUE)
    print(f"Processing payment: ${amount} with card {card_number}")
    
    # No input validation for amount or card number (SECURITY ISSUE)
    # No encryption for sensitive data (SECURITY ISSUE)
    
    # Simulated payment processing
    if amount > 0:
        return {"status": "success", "transaction_id": "12345"}
    else:
        return {"status": "failed", "error": "Invalid amount"}


def fibonacci(n):
    """Calculate fibonacci number - has performance issues"""
    # Inefficient recursive implementation (PERFORMANCE ISSUE)
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)


# Unused function (CODE QUALITY ISSUE)
def unused_function():
    """This function is never called"""
    pass


if __name__ == "__main__":
    # Example usage with problematic code
    
    try:
        manager = UserManager()
        
        # Adding user with plain text password (SECURITY ISSUE)
        user = manager.add_user("John Doe", "john@example.com", "password123")
        
        # Potential issues with API call and error handling
        # user_info = get_user_info(999)  # Uncomment to test error handling
        
        # Could cause division by zero (ERROR HANDLING ISSUE)
        items = [{"name": "item1", "price": 10}, {"name": "item2", "price": 20}]
        total, avg = calculate_total(items)
        
        print(f"Total: ${total}, Average: ${avg}")
        
        # Security risk - processing payment with sensitive data logging
        result = process_payment(100.0, "1234-5678-9012-3456")
        
        # File operations without proper validation
        save_to_file({"users": len(manager.users)}, "output.json")
        
        # Performance issue - inefficient fibonacci calculation
        fib_result = fibonacci(10)  # Try with larger numbers to see performance impact
        print(f"Fibonacci(10) = {fib_result}")
        
    except Exception as e:
        # Generic exception handling (ERROR HANDLING ISSUE)
        print(f"An error occurred: {e}")