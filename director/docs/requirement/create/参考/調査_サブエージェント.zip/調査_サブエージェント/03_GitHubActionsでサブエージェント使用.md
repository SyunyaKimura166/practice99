# 3. GitHubActionsにおけるClaudeサブエージェント使用方法<!-- omit in toc -->

GitHub プルリクエストで自動コードレビューを行うClaude Sub-Agentのリポジトリを作成。

### 目次<!-- omit in toc -->

- [3.1. 概要](#31-概要)
- [3.2. ファイル構成](#32-ファイル構成)
- [3.3. 仕組み](#33-仕組み)
  - [3.3.1. 全体の流れ](#331-全体の流れ)
  - [3.3.2. 詳細なワークフロー](#332-詳細なワークフロー)
  - [3.3.3. 技術的な仕組み](#333-技術的な仕組み)
- [3.4. 必要な設定](#34-必要な設定)
- [3.5. 使い方](#35-使い方)
- [3.6. Sub-Agentのレビュー内容](#36-sub-agentのレビュー内容)
- [3.7. テスト用サンプル](#37-テスト用サンプル)
- [3.8. カスタマイズ](#38-カスタマイズ)

## 3.1. 概要

本資料では、GitHub ActionsワークフローからClaudeサブエージェントを実行する基本的な方法について解説する。

このリポジトリでは以下を実現：

- **自動コードレビュー**: プルリクエスト作成時にClaude Sub-Agentが自動実行
- **専門的分析**: セキュリティ、パフォーマンス、コード品質を総合評価
- **教育的フィードバック**: 問題点だけでなく改善方法も提案

## 3.2. ファイル構成

### 3.2.1. フォルダ構成

```
claude-sub-agent/
├── .claude/agents/
│   └── code-reviewer.md    # Sub-Agent定義（コードレビュー専門）
├── .github/workflows/
│   └── code-review.yml     # GitHub Actions設定
├── src/
│   └── sample.py           # テスト用サンプルコード
└── README.md
```

### 3.2.2. ファイル説明

各ファイルの役割と内容について詳しく説明する。

#### [.claude/agents/code-reviewer.md](./.claude/agents/code-reviewer.md)
**役割**: Claudeサブエージェントの定義ファイル

**内容**:
- サブエージェントの名前と説明
- システムプロンプト（AIの振る舞いを指定）
- レビュー観点（セキュリティ、パフォーマンス、コード品質など）
- 出力形式の指定

**カスタマイズ可能な項目**:
- レビューの重点項目
- 指摘レベルの基準
- 出力言語とフォーマット

#### [.github/workflows/code-review.yml](./.github/workflows/code-review.yml)
**役割**: GitHub Actionsワークフローの定義

**内容**:
- トリガー条件（プルリクエスト作成時）
- AWS認証の設定
- Claude APIの呼び出し処理
- レビュー結果のコメント投稿

**主要設定項目**:
- `on.pull_request.paths`: レビュー対象ファイルのパス
- 環境変数の設定
- Claude実行コマンド

#### [src/sample.py](./src/sample.py)
**役割**: テスト用のサンプルコード

**内容**:
- 意図的に問題を含むPythonコード
- セキュリティ、パフォーマンス、品質の問題例
- サブエージェントの動作確認用

**含まれる問題例**:
- 入力値検証の不備
- 非効率なアルゴリズム
- 例外処理の欠如
- グローバル変数の不適切な使用


## 3.3. 仕組み

### 3.3.1. 全体の流れ

このシステムは、GitHub上でプルリクエストが作成されると自動的にAIによるコードレビューを実行する仕組みである。

```
開発者がコード変更 → プルリクエスト作成 → 自動レビュー実行 → 結果をコメント
```

### 3.3.2. 詳細なワークフロー

**ステップ1: 開発者の作業**
- 開発者がコードを修正・追加
- GitHubでプルリクエスト（PR）を作成

**ステップ2: GitHub Actionsの自動実行**
- PRの作成/更新を検知してワークフローが自動開始
- `.github/workflows/code-review.yml`で定義された処理が実行

**ステップ3: Claudeサブエージェントによる分析**
- AWS Bedrock経由でClaude AIに接続
- `.claude/agents/code-reviewer.md`で定義されたサブエージェントが起動
- 変更されたコードファイルを詳細に分析

**ステップ4: レビュー結果の投稿**
- 分析結果を自動的にPRのコメントとして投稿
- 問題点の指摘と改善提案を含む包括的なフィードバック

### 3.3.3. 技術的な仕組み

```mermaid
graph LR
    A[プルリクエスト作成] --> B[GitHub Actions実行]
    B --> C[AWS認証]
    C --> D[Claude API呼び出し]
    D --> E[サブエージェント実行]
    E --> F[コードレビュー分析]
    F --> G[結果をPRにコメント]
```

**使用する技術要素**:
- **GitHub Actions**: 自動化ワークフローの実行基盤
- **AWS Bedrock**: Claude AIへの安全なアクセス
- **Claude Sonnet**: 高精度なコード分析AI
- **Sub-Agent**: 専門特化したレビュー機能

## 3.4. 必要な設定

### AWS設定

**1. OIDC Identity Provider**

手順:
AWS Management Console > IAM > IDプロバイダ > プロバイダを追加

```
Provider URL: https://token.actions.githubusercontent.com
Audience: sts.amazonaws.com
```

**2. IAMロール**
- 信頼関係でGitHub Actions OIDC認証を設定
- `bedrock:InvokeModel`権限を付与

**ポリシーJSON:**

手順:
AWS Management Console > IAM > ポリシー > ポリシーの作成

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": "*"
    }
  ]
}
```

**IAMロール信頼関係JSON:**

手順:
AWS Management Console > IAM > ロール > ロールを作成

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::[ACCOUNT-ID]:oidc-provider/token.actions.githubusercontent.com"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
        },
        "StringLike": {
          "token.actions.githubusercontent.com:sub": "repo:[Owner]/[Repo]:*"
        }
      }
    }
  ]
}
```

### GitHub設定  

**Repository Secrets**

Settings > Secrets and variables > New repository secret

| 変数名 | 値の例 | 説明 |
|--------|--------|------|
| `AWS_ROLE_ARN` | `arn:aws:iam::[ACCOUNT-ID]:role/GitHubActionsClaudeSubAgentRole` | AWS BedrockにアクセスするためのIAMロールARN |
| `AWS_REGION` | `ap-northeast-1` | Claude AIが利用可能なAWSリージョン |
| `CLAUDE_MODEL` | `global.anthropic.claude-sonnet-4-5-20250929-v1:0` | 使用するClaudeモデルのID |

**Actions権限**
- Settings > Actions > General
- "Read and write permissions"を有効
- "Allow GitHub Actions to create and approve pull requests"をチェック

## 3.5. 使い方

1. `src/`内のファイルを編集
2. プルリクエストを作成
3. 数分でClaude Sub-Agentによるレビューがコメントされる

![画像16](images/画像16.png)

## 3.6. Sub-Agentのレビュー内容

**🔴 Critical** - セキュリティ脆弱性、データ損失リスク  
**🟡 Major** - パフォーマンス問題、設計上の課題  
**🟢 Minor** - コードスタイル、軽微な改善提案  
**💡 Suggestion** - より良い実装パターンの提案

![画像17](images/画像17.png)

## 3.7. テスト用サンプル

`src/sample.py`には意図的に以下の問題を含めている：

- 入力値検証の不備（セキュリティ）
- 非効率なアルゴリズム（パフォーマンス）
- 例外処理の欠如（エラーハンドリング）
- グローバル変数の使用（コード品質）

これらをSub-Agentがどのように検出・分析するかを確認できる。

## 3.8. カスタマイズ

システムの動作を自分のプロジェクトに合わせて調整する方法について説明する。

### 8.1. レビュー基準のカスタマイズ

**対象ファイル**: `.claude/agents/code-reviewer.md`

**変更方法**:
1. `.claude/agents/`ディレクトリ内のマークダウンファイルを開く
2. サブエージェントの指示文（プロンプト）を編集
3. レビュー観点、重要度、出力形式などを調整

**カスタマイズ例**:
```markdown
# レビュー観点を追加
- セキュリティチェック
- パフォーマンス最適化
- コードの可読性
- テストカバレッジ

# 出力形式を指定
レビュー結果は以下の形式で出力すること：
- 🔴 Critical: 即座に修正が必要
- 🟡 Major: 次回リリースまでに修正
- 🟢 Minor: 時間があるときに修正
```

### 8.2. 対象ファイルの設定

**対象ファイル**: `.github/workflows/code-review.yml`

**変更箇所**: `paths`設定部分
```yaml
on:
  pull_request:
    paths:
      - 'src/**/*.py'        # Pythonファイルのみ
      - 'lib/**/*.js'        # JavaScriptファイルも追加
      - 'config/**/*.yaml'   # 設定ファイルも対象に
```

**設定パターン**:
- **特定フォルダのみ**: `'src/**'`
- **特定拡張子のみ**: `'**/*.py'`
- **複数パターン**: 上記例のように複数行で指定
- **除外パターン**: `'!tests/**'` （testsフォルダを除外）

### 8.3. Claudeモデルの変更

**変更場所**: GitHub Repository Secrets

**手順**:
1. GitHub リポジトリページで `Settings` > `Secrets and variables` > `Actions`
2. `CLAUDE_MODEL` をクリックして編集
3. 使用したいモデルIDに変更

**利用可能なモデル例**:
- `global.anthropic.claude-sonnet-4-5-20250929-v1:0` (推奨: バランスが良い)
- `global.anthropic.claude-haiku-4-5-20250929-v1:0` (高速・軽量)
- `global.anthropic.claude-opus-4-5-20250929-v1:0` (高精度・詳細)

**選択指針**:
- **速度重視**: Haiku（軽微なレビュー向け）
- **バランス**: Sonnet（一般的な用途）  
- **精度重視**: Opus（重要なコードレビュー）

### 8.4. 高度なカスタマイズ

**複数のサブエージェントを使い分ける**:
```yaml
# .github/workflows/code-review.yml の一部
- name: Security Review
  if: contains(github.event.pull_request.changed_files, 'auth/')
  run: claude code --agent security-reviewer

- name: Performance Review  
  if: contains(github.event.pull_request.changed_files, 'api/')
  run: claude code --agent performance-reviewer
```

**レビュー結果の詳細度調整**:
`.claude/agents/`ファイル内で以下を指定：
```markdown
# 詳細レベル: 1-5 (5が最詳細)
詳細レベル: 3

# 最大指摘数
最大指摘数: 10

# 改善提案の形式
改善提案には具体的なコード例を含めること
```

***

[目次](./01_はじめに.md#はじめに)
