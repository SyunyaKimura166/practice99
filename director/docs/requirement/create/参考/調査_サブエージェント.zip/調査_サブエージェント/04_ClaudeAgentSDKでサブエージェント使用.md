# 4. ClaudeAgentSDKでサブエージェント使用<!-- omit in toc -->

Claude Agent SDK for Pythonを使用して、プログラム的にサブエージェントを定義・実行する方法について調査した結果を記載する。

## 目次<!-- omit in toc -->

- [4.1. 概要](#41-概要)
- [4.2. 調査目的](#42-調査目的)
- [4.3. 実装方針](#43-実装方針)
  - [4.3.1. 環境構築とインストール](#431-環境構築とインストール)
  - [4.3.2. 対象タスク](#432-対象タスク)
  - [4.3.3. サブエージェント構成](#433-サブエージェント構成)
  - [4.3.4. サブエージェント定義方法](#434-サブエージェント定義方法)
- [4.4. サンプル実装](#44-サンプル実装)
- [4.5. コード詳細解説](#45-コード詳細解説)
- [4.6. 実行結果](#46-実行結果)
- [4.7. 技術的課題と解決策](#47-技術的課題と解決策)
- [4.8. まとめ](#48-まとめ)

## 4.1. 概要

Claude Agent SDK for Pythonにおけるサブエージェント機能は、メインエージェントから独立した専門化されたAIエージェントを作成・実行する機能である。本調査では、公式GitHubリポジトリの`agents.py`サンプルプログラムを参考に、Pythonでのサブエージェント実装方法を検証した。

## 4.2. 調査目的

本調査では、Claude Agent SDK for Pythonを使用したサブエージェントの実装方法を明らかにするため、以下の5つの項目について調査した。各項目の調査結果は8章のまとめで対応する成果として報告する。

- **公式サンプルプログラムの活用**: Claude Agent SDK Pythonの`agents.py`サンプルを参考にした実装 → [8.1の成果1]
- **動的エージェント定義**: プログラム内でサブエージェントを定義する方法 → [8.1の成果2]
- **並行処理の実現**: 複数のサブエージェントを同時実行 → [8.1の成果3]
- **専門化されたタスク分担**: Pythonコードレビューにおける役割分担の実証 → [8.1の成果4]
- **コンテキスト分離**: 各サブエージェントの独立したコンテキスト管理 → [8.2の技術的知見]

## 4.3. 実装方針

### 4.3.1. 環境構築とインストール

**Claude Agent SDK for Pythonのインストール**:
```bash
pip install claude-agent-sdk
```

**必要な依存関係**:
- Python 3.10以上
- anyio (非同期処理用)
- その他の依存関係は自動的にインストールされる

**インストール確認**:
```python
try:
    from claude_agent_sdk import AgentDefinition, ClaudeAgentOptions, query
    print("Claude Agent SDK for Python のインストールが完了しました")
except ImportError:
    print("❌ claude-agent-sdk がインストールされていません")
    print("インストール: pip install claude-agent-sdk")
```

### 4.3.2. 対象タスク
Pythonコードの包括的品質レビュー
- **品質レビュー**: PEP 8、可読性、保守性の分析
- **パフォーマンスレビュー**: アルゴリズム最適化、メモリ使用量の分析
- **セキュリティレビュー**: 脆弱性検出、セキュアコーディングの分析

### 4.3.3. サブエージェント構成

本実装では、`AgentDefinition`を使用してプログラム内で動的にサブエージェントを定義する：

**実装されるエージェント例**:
- **code-reviewer**: コード品質とベストプラクティスのレビュー
- **doc-writer**: 技術ドキュメントの作成と説明
- **analyzer**: コード構造とパターンの分析
- **tester**: テストの作成と品質保証

各エージェントの特徴：
- **カスタマイズ可能なプロンプト**: タスクに特化した指示
- **ツール制限**: 必要な機能のみを許可
- **モデル指定**: 適切なClaudeモデルの選択

### 4.3.4. サブエージェント定義方法

Claude Agent SDK for Pythonでは、2つの定義方法が提供されている：

#### 3.4.1. プログラム的定義（推奨）
`AgentDefinition`を使用してコード内でエージェントを動的に定義する方法：
```python
from claude_agent_sdk import AgentDefinition, ClaudeAgentOptions

options = ClaudeAgentOptions(
    agents={
        "code-reviewer": AgentDefinition(
            description="Reviews code for best practices",
            prompt="You are a code reviewer...",
            tools=["Read", "Grep"],
            model="sonnet",
        ),
    },
)
```

**利点**:
- 柔軟性: 実行時の条件に応じた動的な設定変更
- 可読性: コードと設定が同一ファイルで管理
- 型安全性: Python型システムによる検証

#### 3.4.2. ファイルシステムベース定義（代替）
`.claude/agents/`ディレクトリにMarkdownファイルでエージェントを定義する方法：
```
.claude/agents/
├── code-reviewer.md
├── doc-writer.md
└── analyzer.md
```

**利点**:
- 管理の容易さ: 設定ファイルの外部管理
- 再利用性: 複数プロジェクトでの共有
- 非プログラマーでも編集可能

**使用例**:
```python
# ファイルシステムベースの場合、agents パラメータを省略
options = ClaudeAgentOptions()
# .claude/agents/ 内のファイルが自動的に読み込まれる
```

## 4.4. サンプル実装

### 4.4.1. ファイル構成
```
examples/
└── agents.py  # 公式サンプルプログラム
```

**参考元**: [Claude Agent SDK Python Examples](https://github.com/anthropics/claude-agent-sdk-python/tree/main/examples)

### 4.4.2. 実装コード概要

本実装は、Claude Agent SDK Python の公式サンプルプログラムに基づいている。

**参照実装**: [agents.py - Claude Agent SDK Python Examples](https://github.com/anthropics/claude-agent-sdk-python/blob/main/examples/agents.py)

公式サンプルプログラムでは以下の実装パターンが提供されている：

- **動的エージェント定義**: `AgentDefinition`を使用したプログラム内でのサブエージェント定義
- **query()関数の活用**: Claude Agent SDKのコア機能を使用した実行
- **async/awaitパターン**: 非同期処理によるレスポンス取得
- **エラーハンドリング**: 適切な例外処理の実装
- **コスト管理**: リアルタイムでのコスト追跡と表示

詳細なコード実装については、上記の公式GitHubリポジトリを参照。

## 4.5. コード詳細解説

本章では、Claude Agent SDK Python の公式サンプルプログラム `agents.py` で使用されている主要なコード実装パターンについて詳しく解説する。これらのパターンは、サブエージェントの定義から実行、結果処理まで一連の流れを理解するために重要である。

**参照**: [agents.py - Claude Agent SDK Python Examples](https://github.com/anthropics/claude-agent-sdk-python/blob/main/examples/agents.py)

### 4.5.1. AgentDefinitionを使用したエージェント定義

`agents.py`では、`AgentDefinition`クラスを使用してサブエージェントをプログラム内で動的に定義している。この方法により、実行時にエージェントの設定を柔軟に変更できる。

**公式サンプルパターン**:
```python
from claude_agent_sdk import AgentDefinition, ClaudeAgentOptions

options = ClaudeAgentOptions(
    agents={
        "code-reviewer": AgentDefinition(
            description="Reviews code for best practices and potential issues",
            prompt="You are a code reviewer. Analyze code for bugs, "
                   "performance issues, security vulnerabilities, and adherence to best practices. "
                   "Provide constructive feedback.",
            tools=["Read", "Grep"],
            model="sonnet",
        ),
    },
)
```

**パラメータ詳細**:
- `description`: エージェントの役割を説明する短い文
- `prompt`: エージェントの振る舞いを定義するシステムプロンプト
- `tools`: エージェントが使用可能なツールのリスト（"Read", "Grep", "Write", "Bash"など）
- `model`: 使用するClaudeモデル（"sonnet", "haiku", "opus"）

**実装のポイント**:
- 辞書形式でエージェント名をキーとして定義
- 各エージェントに特化したプロンプトを設定
- 必要最小限のツールのみを許可してセキュリティを確保

### 4.5.2. 複数エージェントの定義と使用

`agents.py`の`multiple_agents_example()`関数では、複数のエージェントを同時に定義し、それぞれ異なる専門性を持たせている。

**複数エージェントパターン**:
```python
options = ClaudeAgentOptions(
    agents={
        "analyzer": AgentDefinition(
            description="Analyzes code structure and patterns",
            prompt="You are a code analyzer. Examine code structure, patterns, and architecture.",
            tools=["Read", "Grep", "Glob"],
        ),
        "tester": AgentDefinition(
            description="Creates and runs tests",
            prompt="You are a testing expert. Write comprehensive tests and ensure code quality.",
            tools=["Read", "Write", "Bash"],
            model="sonnet",
        ),
    },
    setting_sources=["user", "project"],
)
```

**実装の特徴**:
- 各エージェントが異なるツールセットを使用
- `analyzer`: ファイル検索に特化（"Glob"ツール使用）
- `tester`: テスト作成・実行に特化（"Write", "Bash"ツール使用）
- `setting_sources`: 設定ファイルの読み込みソースを指定

**エージェント間の役割分担**:
- コード分析とテスト作成を分離することで専門性を向上
- 各エージェントが独立して動作し、結果を統合

### 4.5.3. メッセージ処理とコスト表示

`agents.py`では、`query()`関数の戻り値を非同期ストリームとして処理し、リアルタイムでレスポンスとコスト情報を表示している。

**非同期メッセージ処理**:
```python
async for message in query(prompt="...", options=options):
    if isinstance(message, AssistantMessage):
        for block in message.content:
            if isinstance(block, TextBlock):
                print(f"Claude: {block.text}")
    elif isinstance(message, ResultMessage) and message.total_cost_usd and message.total_cost_usd > 0:
        print(f"\nCost: ${message.total_cost_usd:.4f}")
```

**メッセージタイプ別処理**:
- `AssistantMessage`: エージェントからの応答メッセージ
  - `content`属性に複数のブロック（テキスト、ツール使用結果など）が含まれる
  - `TextBlock`を抽出してレスポンステキストを表示
- `ResultMessage`: 実行完了とコスト情報
  - `total_cost_usd`属性でコスト情報を取得
  - 小数点以下4桁まで表示してコスト管理を支援

**ストリーミング処理の利点**:
- レスポンスをリアルタイムで確認可能
- 長時間の処理でも進捗を把握できる
- コスト情報を即座に確認してコスト管理が可能

## 4.6. 実行結果

### 4.6.1. 実行コマンド
```bash
python examples/agents.py
```

**注記**: 詳細な実行手順や依存関係については、[Claude Agent SDK Python公式リポジトリ](https://github.com/anthropics/claude-agent-sdk-python)を参照。

### 4.6.2. 出力例
公式サンプルプログラムの実行により、以下のような出力が期待される：

```
=== Code Reviewer Agent Example ===
Claude: [code-reviewerエージェントによるコードレビュー結果]
ファイル src/claude_agent_sdk/types.py の分析結果、
ベストプラクティス、潜在的な問題の指摘、
セキュリティ脆弱性のチェック結果などが表示されます。

Cost: $0.0234

=== Documentation Writer Agent Example ===
Claude: [doc-writerエージェントによるドキュメント作成結果]
AgentDefinitionの使用方法、パラメータの詳細説明、
実装例を含む包括的なドキュメントが生成されます。

Cost: $0.0187

=== Multiple Agents Example ===
Claude: [analyzerエージェントによるファイル分析結果]
examples/ディレクトリ内のPythonファイルの一覧、
コード構造やパターンの分析結果が表示されます。

Cost: $0.0156
```

## 4.7. 技術的課題と解決策

本章では、Claude Agent SDK for Pythonを使用してサブエージェントを実装する際に遭遇する主要な技術的課題と、公式サンプルプログラムで採用されている解決策について説明する。

### 4.7.1. エージェント設定管理の課題と解決策

#### 7.1.1. 課題：静的設定の制約
**問題**:
- 固定的なエージェント設定では、実行時の条件変化に対応できない
- 異なるプロジェクトやタスクに同じエージェントを流用する際の柔軟性不足
- 設定ファイルベースでは、プログラムロジックとの連携が困難

#### 7.1.2. 解決策：AgentDefinitionによる動的設定
**`agents.py`での実装アプローチ**:
```python
# 実行時にタスクに応じてエージェント設定を動的に変更
def create_code_reviewer(language="python", strictness="normal"):
    return AgentDefinition(
        description=f"Reviews {language} code with {strictness} strictness",
        prompt=f"You are a {language} code reviewer. Apply {strictness} standards...",
        tools=["Read", "Grep"],
        model="sonnet" if strictness == "strict" else "haiku",
    )

# 動的にエージェントを生成
options = ClaudeAgentOptions(
    agents={
        "code-reviewer": create_code_reviewer(language="python", strictness="strict"),
    },
)
```

**解決される問題**:
- プログラム実行時にエージェントを動的に定義
- 異なるタスクに応じたエージェントのカスタマイズ
- 実行時パラメータに基づくエージェント設定の変更

#### 7.1.3. メッセージ処理の複雑性への対応
**課題**: 複数の異なるメッセージタイプの適切な処理

**解決策**: 型チェックによる安全な処理分岐
```python
# AssistantMessage: エージェントからのレスポンス
if isinstance(message, AssistantMessage):
    # テキストコンテンツの処理
    for block in message.content:
        if isinstance(block, TextBlock):
            print(f"Claude: {block.text}")
        elif isinstance(block, ToolUseBlock):
            print(f"Tool used: {block.name}")
    
if isinstance(message, ResultMessage):
    # コスト情報の表示
    if message.total_cost_usd:
        print(f"Cost: ${message.total_cost_usd:.4f}")
```

### 4.7.2. パフォーマンスとコスト管理の課題と解決策

#### 7.2.1. 課題：コスト予測の困難さ
**問題**:
- 複数エージェントの同時実行時のコスト予測が困難
- 長時間実行時のコスト把握ができない
- 予算超過のリスク管理ができない

#### 7.2.2. 解決策：リアルタイムコスト監視
**`agents.py`での実装例**:
```python
total_cost = 0.0

async for message in query(prompt="...", options=options):
    if isinstance(message, ResultMessage) and message.total_cost_usd:
        total_cost += message.total_cost_usd
        print(f"Current session cost: ${total_cost:.4f}")
        
        # コスト上限チェック
        if total_cost > MAX_BUDGET:
            print("⚠️ Budget exceeded, stopping execution")
            break
```

**解決される問題**:
- `ResultMessage.total_cost_usd`によるリアルタイムコスト表示
- エージェントごとのコスト追跡が可能
- 予算管理とコスト最適化の実現

#### 7.2.3. 課題：設定管理の分散化
**問題**:
- ユーザー設定、プロジェクト設定、システム設定の統合管理
- 設定の優先順位や上書き規則の複雑化
- 設定ファイルの場所や形式の不統一

#### 7.2.4. 解決策：setting_sourcesによる統合管理
**実装例**:
```python
options = ClaudeAgentOptions(
    agents={...},
    setting_sources=["user", "project"],  # 設定ソースの指定
)
```

**設定の優先順位**:
1. `"user"`: ユーザーの個人設定（`~/.config/claude/`）
2. `"project"`: プロジェクト固有の設定（`.claude/`）
3. システムデフォルト設定

**解決される問題**:
- 複数の設定ソースの統合管理
- 設定の優先順位の明確化
- プロジェクト間での設定の使い分け

#### 7.2.5. 課題：長時間実行時の監視
**問題**:
- 長時間実行するエージェントの進捗が不明
- 処理の途中でエラーが発生した場合の対処
- レスポンス待ちでの無応答状態

#### 7.2.6. 解決策：ストリーミング処理とタイムアウト管理
**実装例**:
```python
import asyncio

async def execute_with_timeout(prompt, options, timeout=300):  # 5分タイムアウト
    try:
        async with asyncio.timeout(timeout):
            async for message in query(prompt=prompt, options=options):
                # リアルタイム進捗表示
                if isinstance(message, AssistantMessage):
                    print(".", end="", flush=True)  # 進捗表示
                yield message
    except asyncio.TimeoutError:
        print("⚠️ Execution timeout - stopping")
        raise
```

**解決される問題**:
- リアルタイムでの進捗監視
- タイムアウトによる無限実行の防止
- エラー時の適切な処理停止

## 4.8. まとめ

本章では、2章で設定した調査目的に対する結果をまとめる。各調査項目で確認できた成果、得られた技術的知見、および今後の推奨使用パターンについて報告する。

### 8.1. 調査成果

2章で設定した5つの調査目的に対して、以下の成果を得ることができた：

1. **公式サンプル活用**: Claude Agent SDK Python の`agents.py`サンプルプログラムを参考にした実装パターンの確立
2. **動的エージェント定義**: `AgentDefinition`を使用したプログラム内でのサブエージェント動的定義
3. **実用的な実装**: 公式サンプルに基づく、即座に導入可能なコード構造
4. **包括的機能**: コードレビュー、ドキュメント作成、分析、テストの統合ソリューション

### 8.2. 技術的知見

調査過程で得られた主要な技術的知見は以下の通りである：

- **公式サンプル準拠**: GitHub公式リポジトリのサンプルプログラムに基づく確実な実装
- **動的エージェント定義**: 実行時のサブエージェント作成と柔軟な設定
- **型安全な処理**: メッセージタイプ別の安全な処理とエラーハンドリング
- **コスト最適化**: リアルタイムコスト追跡による効率的な利用
- **保守性**: 公式サンプルに準拠することによる高い保守性とサポート

### 8.3. 推奨使用パターン

**公式サンプル準拠パターンが適している場合**:
- 公式サポートと互換性を重視
- 確実に動作する実装を優先
- 最新の機能とベストプラクティスを活用したい
- コミュニティサポートを重視する場合
- 柔軟なエージェント設定が必要な場合

### 8.4. 実装上の注意点
* **Claude Code CLIとの相違:** Claude Code CLIで`claude /agents`コマンドでサブエージェントを定義するときに色を指定できるが、SDKでは現時点で色を指定するパラメータは存在しない。

***

[目次](./01_はじめに.md#はじめに)
